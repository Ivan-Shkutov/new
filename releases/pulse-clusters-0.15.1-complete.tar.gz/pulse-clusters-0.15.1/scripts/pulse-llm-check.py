#!/usr/bin/env python3
"""Run the local model check from a source installation using only stdlib."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from pulse_app.llm_check import main
raise SystemExit(main())
